from django.db import models
from django.utils import timezone
from django.contrib.auth.models import User
from django.urls import reverse

# Create your models here.

class Site(models.Model):
    url = models.CharField(max_length=255, null=False)
    date_posted = models.DateTimeField(default=timezone.now)
    online = models.BooleanField(default=True)
    isValid = models.BooleanField(default=False)
    author = models.ForeignKey(User, on_delete=models.SET_NULL, null=True)

    def __str__(self):
        return self.url

    def get_absolute_url(self):
        return reverse('site-detail', kwargs={'pk': self.pk})
    