from django.shortcuts import render, get_object_or_404
from django.contrib.auth.models import User
from django.contrib.auth.mixins import LoginRequiredMixin, UserPassesTestMixin
from django.views.generic import ListView, DetailView, CreateView, UpdateView, DeleteView
from django.db.models import Q
from .models import Site

# Create your views here.
def home(request):
    context = {
        'sites': Site.objects.all()
    }
    return render(request, 'phish/home.html', context)

def all(request):
    context = {
        'sites': Site.objects.all()
    }
    return render(request, 'phish/all.html', context)

class SearchResultsView(ListView):
    model = Site
    template_name = 'phish/serach_results.html'
    context_object_name = 'sites'

    def get_queryset(self):
        query = self.request.GET.get('url')
        object_list = Site.objects.filter(
            Q(url__icontains=query)
        )
        return object_list.order_by('-date_posted')
        


class SiteListView(ListView):
    model = Site
    template_name = 'phish/home.html'
    context_object_name = 'sites'
    ordering = ['-date_posted']
    paginate_by = 10

class SiteDetailView(DetailView):
    model = Site

class SiteCreateView(LoginRequiredMixin, CreateView):
    model = Site
    fields = ['url']

    def form_valid(self, form):
        form.instance.author = self.request.user
        return super().form_valid(form)

class SiteUpdateView(LoginRequiredMixin, UserPassesTestMixin, UpdateView):
    model = Site
    fields = ['url']

    def form_valid(self, form):
        form.instance.author = self.request.user
        return super().form_valid(form)

    def test_func(self):
        site = self.get_object()
        if self.request.user == site.author:
            return True
        return False

class SiteDeleteView(LoginRequiredMixin, UserPassesTestMixin, DeleteView):
    model = Site
    success_url = '/'

    def test_func(self):
        site = self.get_object()
        if self.request.user == site.author:
            return True
        return False

class UserSiteListView(ListView):
    model = Site
    template_name = 'phish/user_sites.html'
    context_object_name = 'sites'

    paginate_by = 10

    def get_queryset(self):
        user = get_object_or_404(User, username=self.kwargs.get('username'))
        return Site.objects.filter(author=user).order_by('-date_posted')