from django.urls import path
from . import views
from .views import SiteListView, SiteDetailView, SiteCreateView, SiteUpdateView, SiteDeleteView, UserSiteListView, SearchResultsView

urlpatterns = [
    path('', SiteListView.as_view(), name='phish-home'),
    path('all/', views.all, name='all-sites'),
    path('search/', SearchResultsView.as_view(), name='search-results'),
    path('user/<str:username>', UserSiteListView.as_view(), name='user-sites'),
    path('site/<int:pk>/', SiteDetailView.as_view(), name='site-detail'),
    path('site/new/', SiteCreateView.as_view(), name='site-create'),
    path('site/<int:pk>/update', SiteUpdateView.as_view(), name='site-update'),
    path('site/<int:pk>/delete', SiteDeleteView.as_view(), name='site-delete'),
    
]