from django.apps import AppConfig


class PhishConfig(AppConfig):
    name = 'phish'
